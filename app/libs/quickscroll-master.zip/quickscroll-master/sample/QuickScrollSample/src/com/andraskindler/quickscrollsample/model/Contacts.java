package com.andraskindler.quickscrollsample.model;

public class Contacts {

	public static final String[] sContacts = { "Abbie", "Andy", "Anne", "Audrey", "Bernadette", "Bob", "Camille", "Charlotte", "Christopher", "David", "Donna", "Elizabeth", "Ethan", "Frederick", "Gabriel", "Gwen", "Hailey", "Holly", "Ian", "Ildiko", "Isaiah", "Ivanna", "Jane", "Jenny", "Johnathan", "Jonas", "Kate", "Kevin", "Kiefer", "Lana", "Lamar", "Lee", "Macbeth", "Martha", "Megan", "Natalie", "Nate", "Nora", "Olga", "Ophelia", "Otto", "Peter", "Perry", "Ramona", "Rashida", "Rita", "Robert", "Roberta", "Salvador", "Samuel", "Stacy", "Tabitha", "Tina", "Tom", "Ubul", "Valerie", "Vanessa", "Vladimir", "Waldo", "Wilhelmina", "Xander", "Yvette", "Zabrina", "Zohan" };

}